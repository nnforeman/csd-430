<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="model.TravelRecord" %>

<%
/*
Name: Natasha Foreman
Course: CSD 430 -  Server Side Development
Date: 7/5/26
Assignment: Module 4.2
Purpose: This JSP page uses a JavaBean to display travel records in an HTML table.
*/

    String pageTitle = "States I Have Enjoyed Visiting";
    String description = "This page displays travel data using a JavaBean. Each record includes state, location, reason, category, and visit type.";

    TravelRecord[] records = {
        new TravelRecord("Nebraska", "Omaha", "Farmers market and local attractions", "Local Travel", "Weekend Trip"),
        new TravelRecord("Oklahoma", "Oklahoma City", "Bricktown and downtown area", "City Travel", "Vacation"),
        new TravelRecord("South Dakota", "Niobrara Area", "Outdoor scenery and river float", "Outdoor Travel", "Day Trip"),
        new TravelRecord("Kansas", "Kansas City Area", "Food, shopping, and family attractions", "Family Travel", "Weekend Trip"),
        new TravelRecord("Missouri", "St. Louis", "History, city views, and attractions", "City Travel", "Vacation")
    };
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><%= pageTitle %></title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<div class="container">

    <h1><%= pageTitle %></h1>

    <p class="description"><%= description %></p>

    <h2>Overall Data Description</h2>
    <p>
        The table below contains five travel records based on states I have enjoyed visiting.
        The data is stored in JavaBean objects and displayed dynamically through a JSP page.
    </p>

    <h2>Field Descriptions</h2>
    <ul>
        <li><strong>State:</strong> The state visited.</li>
        <li><strong>Location:</strong> City or area visited.</li>
        <li><strong>Reason:</strong> Why the visit was enjoyable.</li>
        <li><strong>Category:</strong> The type of travel experience.</li>
        <li><strong>Visit Type:</strong> The general type of trip.</li>
    </ul>

    <h2>Travel Records</h2>

    <table>
        <tr>
            <th>State</th>
            <th>Location</th>
            <th>Reason</th>
            <th>Category</th>
            <th>Visit Type</th>
        </tr>

        <%
            for (TravelRecord record : records) {
        %>
        <tr>
            <td><%= record.getState() %></td>
            <td><%= record.getLocation() %></td>
            <td><%= record.getReason() %></td>
            <td><%= record.getCategory() %></td>
            <td><%= record.getVisitType() %></td>
        </tr>
        <%
            }
        %>
    </table>

</div>
</body>
</html>