package model;

import java.io.Serializable;

public class TravelRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private String state;
    private String location;
    private String reason;
    private String category;
    private String visitType;

    public TravelRecord() {
    }

    public TravelRecord(String state, String location, String reason, String category, String visitType) {
        this.state = state;
        this.location = location;
        this.reason = reason;
        this.category = category;
        this.visitType = visitType;
    }

    public String getState() {
        return state;
    }

    public String getLocation() {
        return location;
    }

    public String getReason() {
        return reason;
    }

    public String getCategory() {
        return category;
    }

    public String getVisitType() {
        return visitType;
    }
}