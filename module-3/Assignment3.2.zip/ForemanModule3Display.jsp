<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%
/*
Name: Natasha Foreman
Course: CSD 430 -  Server Side Development
Date: 6/28/26
Assignment: Module 3.2
Purpose: This JSP page receives form data and displays it in an HTML table.
*/
    String customerName = request.getParameter("customerName");
    String visitDate = request.getParameter("visitDate");
    String mealType = request.getParameter("mealType");
    String serviceRating = request.getParameter("serviceRating");
    String recommend = request.getParameter("recommend");
    String comments = request.getParameter("comments");
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Restaurant Feedback Results</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <div class="container">
        <h1>Restaurant Feedback Results</h1>

        <p class="description">
            The table below displays the feedback information submitted through the restaurant experience form.
        </p>

        <h2>Record Description</h2>
        <p>
            This record contains customer feedback details including customer name, visit date,
            meal type, service rating, recommendation response, and written comments.
        </p>

        <h2>Field Descriptions</h2>
        <ul>
            <li><strong>Customer Name:</strong> Name of the customer submitting feedback.</li>
            <li><strong>Visit Date:</strong> Date the customer visited the restaurant.</li>
            <li><strong>Meal Type:</strong> Type of meal purchased during the visit.</li>
            <li><strong>Service Rating:</strong> Customer service rating from 1 to 5.</li>
            <li><strong>Recommendation:</strong> Indicates whether the customer would recommend the restaurant.</li>
            <li><strong>Comments:</strong> Additional feedback provided by the customer.</li>
        </ul>

        <h2>Submitted Feedback</h2>

        <table>
            <tr>
                <th>Field</th>
                <th>Submitted Data</th>
            </tr>
            <tr>
                <td>Customer Name</td>
                <td><%= customerName %></td>
            </tr>
            <tr>
                <td>Visit Date</td>
                <td><%= visitDate %></td>
            </tr>
            <tr>
                <td>Meal Type</td>
                <td><%= mealType %></td>
            </tr>
            <tr>
                <td>Service Rating</td>
                <td><%= serviceRating %></td>
            </tr>
            <tr>
                <td>Recommendation</td>
                <td><%= recommend %></td>
            </tr>
            <tr>
                <td>Comments</td>
                <td><%= comments %></td>
            </tr>
        </table>

        <p>
            <a href="ForemanModule3Form.jsp">Return to Feedback Form</a>
        </p>
    </div>
</body>
</html>