<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%
/*
Name: Natasha Foreman
Course: CSD 430 -  Server Side Development
Date: 6/28/26
Assignment: Module 3.2
Purpose: This JSP page displays a restaurant feedback form.
*/

%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Restaurant Feedback Form</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <div class="container">
        <h1>Restaurant Experience Feedback Form</h1>

        <p class="description">
            Complete the form to provide feedback about your recent restaurant visit.
        </p>

        <h2>Data Description</h2>
        <p>
            This form gathers customer feedback about the meal quality, service,
            visit date, recommendations, and additional comments.
        </p>

        <form action="ForemanModule3Display.jsp" method="post">
            <label for="customerName">Customer Name:</label>
            <input type="text" id="customerName" name="customerName" required>

            <label for="visitDate">Visit Date:</label>
            <input type="date" id="visitDate" name="visitDate" required>

            <label for="mealType">Meal Type:</label>
            <select id="mealType" name="mealType" required>
                <option value="">Select One</option>
                <option value="Breakfast">Breakfast</option>
                <option value="Lunch">Lunch</option>
                <option value="Dinner">Dinner</option>
            </select>

            <label for="serviceRating">Service Rating:</label>
            <input type="number" id="serviceRating" name="serviceRating" min="1" max="5" required>

            <label>Would you recommend this restaurant?</label>
            <div class="radio-group">
                <input type="radio" id="recommendYes" name="recommend" value="Yes" required>
                <label for="recommendYes">Yes</label>

                <input type="radio" id="recommendNo" name="recommend" value="No">
                <label for="recommendNo">No</label>
            </div>

            <label for="comments">Additional Comments:</label>
            <textarea id="comments" name="comments" rows="4" required></textarea>

            <input type="submit" value="Submit Feedback">
        </form>
    </div>
</body>
</html>