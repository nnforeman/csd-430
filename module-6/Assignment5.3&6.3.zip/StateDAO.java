package database;

import beans.StateRecord;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * Name: Natasha Foreman
 * Course: CSD 430 - Server Side Development
 * Date: 7/12/26
 * Assignment: Modules 5.3 and 6.3 Project Part 1
 * Purpose: Reads state IDs and individual state records from MySQL.
 */
public class StateDAO {

    private static final String TABLE_NAME = "natashastatesdata";

    public List<Integer> getAllStateIds() throws SQLException {
        List<Integer> stateIds = new ArrayList<>();

        String sql = "SELECT state_id FROM " + TABLE_NAME + " ORDER BY state_id";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                stateIds.add(resultSet.getInt("state_id"));
            }
        }

        return stateIds;
    }

    public StateRecord getStateById(int stateId) throws SQLException {
        String sql = "SELECT state_id, state_name, city_location, "
                + "travel_category, visit_type, reason_enjoyed "
                + "FROM " + TABLE_NAME + " WHERE state_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, stateId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new StateRecord(
                            resultSet.getInt("state_id"),
                            resultSet.getString("state_name"),
                            resultSet.getString("city_location"),
                            resultSet.getString("travel_category"),
                            resultSet.getString("visit_type"),
                            resultSet.getString("reason_enjoyed"));
                }
            }
        }

        return null;
    }
}
