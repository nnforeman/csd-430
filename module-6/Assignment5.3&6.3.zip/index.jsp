<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CSD 430 Modules 5 and 6</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<div class="container">

    <h1>CSD 430 Modules 5 and 6</h1>

    <p class="description">
        This project connects to the CSD430 MySQL database and allows a user
        to select and display a state travel record.
    </p>

    <h2>Project Deliverables</h2>

    <ul>
        <li>
            <a href="stateSelect.jsp">Select and Display a State Record</a>
        </li>
    </ul>

</div>
</body>
</html>